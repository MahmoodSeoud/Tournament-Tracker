namespace TicTacToeTest;

using NUnit.Framework;
using TicTacToe;
using TicTacToe.IO;


public class CursorTest {
    private Cursor cursor;

    [SetUp]
    public void Setup() {
        var keyToMoveMap = new KeyToMoveMap('i', 'k', 'j', 'l', 'q', ' ');
        cursor = new Cursor(3, keyToMoveMap);
        cursor.MoveDown();
        cursor.MoveRight();
    }

    [Test]
    public void CursorCenterTest() {
        Assert.True(cursor.position.X == 1 && cursor.position.Y == 1);
    }

    [Test]
    public void MoveUpTest() {
        cursor.MoveUp();
        var pos = (cursor.position.X, cursor.position.Y);
        cursor.MoveUp();
        Assert.True(pos != (pos.Item1+1, pos.Item2+1));
    }

    [Test]
    public void MoveDownTest() {
        cursor.MoveDown();
        var pos = (cursor.position.X, cursor.position.Y);
        cursor.MoveDown();
        Assert.True(pos != (pos.Item1+1, pos.Item2+1));    }
    
    [Test]
    public void MoveLeftTest() {
       cursor.MoveLeft();
        var pos = (cursor.position.X, cursor.position.Y);
        cursor.MoveLeft();
        Assert.True(pos != (pos.Item1+1, pos.Item2+1));
    }

    [Test]
    public void MoveRightTest() {
       cursor.MoveRight();
        var pos = (cursor.position.X, cursor.position.Y);
        cursor.MoveRight();
        Assert.True(pos != (pos.Item1+1, pos.Item2+1));
    }   
}
